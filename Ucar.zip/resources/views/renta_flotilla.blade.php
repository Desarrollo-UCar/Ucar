@extends('plantilla')

@section('seccion')
<h1>Renta de Flotilla</h1>
@endsection