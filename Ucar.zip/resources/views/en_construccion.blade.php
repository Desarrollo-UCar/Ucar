@extends('plantilla')
@section('seccion')
<div class="jumbotron text-center">
    <img src="img/sitio-en-construccion.jpg" class="rounded mx-auto d-block" alt="" style="width:55%"/>  
    <p class="lead">Agradecemos su pronta liberación: </p>
    </p><strong>(Dudas y aclaraciones: desarolloucar@gmail.com)</strong></p>
</div>
@endsection