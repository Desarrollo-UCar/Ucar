@extends('plantilla')
@section('seccion')
<section id="inner-headline">
    <div class="container">
    <div class="row nomargin">
            <div class="jumbotron text-center">
                    <img src="img/exito.jpg" class="rounded mx-auto d-block" alt="" style="width:25%"/>  
                    <h1>--------- </h1>
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <h2 class="animated fadeInDown "><strong><span class="text-success">ANTERIORMENTE ESTA RESERVA YA FUE REALIZADA CON EXITO!!!</span></strong></h2>
                    </div>
                </p><strong>(El pago que acaba de solicitar, NO fue realizado)</strong></p>
                    </p><strong>(Dudas y aclaraciones: desarolloucar@gmail.com)</strong></p>
            </div>
        
    </div>
    </div>
</section>
@endsection

