@extends("theme.$theme.layout")

@section('styles')
  <!-- Morris chart -->
  <link rel="stylesheet" href="{{asset("assets/$theme/bower_components/morris.js/morris.css")}}">

@endsection

@section('contenido')
<section class="content-header">
    <h1>
      Reportes      <small>Graficas</small>
    </h1>
</section>

<section class="content"> 
    <div class="row">
        <div class="col-md-12 ">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
                <li><a data-toggle="tab" href="#menu1">Menu 1</a></li>
                <li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
              </ul>
              
              <div class="tab-content">
                <div id="home" class="tab-pane fade in active">
                  <h3>HOME</h3>
                  <p>Some content.</p>
                </div>
                <div id="menu1" class="tab-pane fade">
                  <h3>Menu 1</h3>
                  <p>Some content in menu 1.</p>
                </div>
                <div id="menu2" class="tab-pane fade">
                  <h3>Menu 2</h3>
                  <p>Some content in menu 2.</p>
                </div>
              </div>
            </div>
        </div>
    </section>

@endsection

@section('scripts')
@endsection