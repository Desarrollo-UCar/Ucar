<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModeloVehiculo extends Model
{
    //
    protected $fillable = [
        'id','nombre'
    ];
}
