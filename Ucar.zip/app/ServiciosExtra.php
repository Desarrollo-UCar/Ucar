<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiciosExtra extends Model
{
    //
     //
     protected $fillable = ['id', 'nombre', 'descripcion','disponibilidad','foto','sucursal','precio'];
}
