<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reserva_temp extends Model
{
    //
}
