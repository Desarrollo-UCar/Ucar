<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarcaModelo extends Model
{
    //
    protected $fillable = [
        'idMarca','idModelo'
    ];
}
