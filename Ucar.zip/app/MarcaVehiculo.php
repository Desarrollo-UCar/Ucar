<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarcaVehiculo extends Model
{
    //
    protected $fillable = [
        'id','nombre'
    ];
}
