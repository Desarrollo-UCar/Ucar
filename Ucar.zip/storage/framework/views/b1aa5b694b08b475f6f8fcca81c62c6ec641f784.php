<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Reservas</title> 
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/tabla.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css')); ?>">
 </head>
<body>
  
<?php $__env->startSection('contenido'); ?>
    <section class="content-header">
        <h1>
          Panel de administración |
          <small>Reservaciones</small>
        </h1>
        
    </section>


    <section class="content">

         <!-- Content Wrapper. Contains page content -->
         <div class="box-body ">
            <table id="example" class="display nowrap " style="width:100%">
                <thead>
                    <tr>
                      <th><small>N/P</small></th>
                      <th>Fecha reservacion</th>
                      <th>Cliente</th>
                      <th><small>identificación/Pasaporte</small></th>
                      <th>Vehiculo</th>
                      <th>Placas</th>
                      <th>Fecha entrega</th>
                      <th>Fecha devolucion</th>
                      <th>Motivo</th>
                      <th>Total</th>
                      <th>Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php if($reservaciones->count()): ?>  
                      <?php $__currentLoopData = $reservaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                      <tr>
                        <td><?php echo e($reservacion->id); ?></td> <!--Datos de la reservacion -->
                        <td><?php echo e(date("d\-m\-Y", strtotime($reservacion->fecha_reservacion))); ?></td>
                      <td><?php echo e($reservacion->nombre); ?> <?php echo e($reservacion->primer_apellido); ?> <?php echo e($reservacion->segundo_apellido); ?></td>
                        <td> <?php if($reservacion->credencial==null): ?>
                            <?php echo e($reservacion->pasaporte); ?>

                            <?php else: ?>
                            <?php echo e($reservacion->credencial); ?>

                            <?php endif; ?> </td>
                        <td><?php echo e($reservacion->marca); ?> <?php echo e($reservacion->modelo); ?> <?php echo e($reservacion->anio); ?> </td>
                        <td><?php echo e($reservacion->matricula); ?> </td>
                        <td><?php echo e(date("d\-m\-Y", strtotime($reservacion->fecha_recogida))); ?></td>
                        <td><?php echo e(date("d\-m\-Y", strtotime($reservacion->fecha_devolucion))); ?> </td>
                        <td><?php echo e($reservacion->motivo_visita); ?></td>
                        <td><?php echo e($reservacion->total); ?></td>  
                       <!-- <td><?php echo e($reservacion->estatus); ?></td> -->
                        <td>  

                          <form action ="<?php echo e(route('reservacion',$reservacion)); ?>" method ="GET" enctype="multipart/form-data">


                                <?php echo e(csrf_field()); ?>

                               <button type="sumbit" class="btn btn-primary btn-xs" type="sumbit">
                               <?php echo e('Detalles  '); ?>

                               <span class="glyphicon glyphicon-new-window"></span>
                               </button>
                          </form>
                      </td>
                        
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                       <?php endif; ?>
                    </tbody>
                  </table>
                </div>

              </div>
     </section>   
     <?php $__env->stopSection(); ?>

     <?php $__env->startSection('scripts'); ?>
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
     <script>
     $(document).ready(function() {
          $('#example').DataTable( {
            "scrollY":"380px",
            "scrollX": true,
            "language": {
              "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
            }
            
          } );
      } );

     </script>

 <?php $__env->stopSection(); ?>
</body>
</html>
  
  
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/gerente/reservaciones/inicio.blade.php ENDPATH**/ ?>