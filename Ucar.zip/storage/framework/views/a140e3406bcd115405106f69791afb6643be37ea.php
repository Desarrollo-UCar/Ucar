<?php $__env->startSection('seccion'); ?>
<div class="jumbotron text-center">
    <img src="img/sitio-en-construccion.jpg" class="rounded mx-auto d-block" alt="" style="width:55%"/>  
    <p class="lead">Agradecemos su pronta liberación: </p>
    </p><strong>(Dudas y aclaraciones: desarolloucar@gmail.com)</strong></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/en_construccion.blade.php ENDPATH**/ ?>