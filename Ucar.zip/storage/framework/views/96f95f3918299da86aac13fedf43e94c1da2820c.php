<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Reservas</title> 
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/tabla.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css')); ?>">
 </head>
<body>
  
<?php $__env->startSection('contenido'); ?>
    <section class="content-header">
        <h1>
          Panel de administración |
          <small>Solicitudes traslados</small>
        </h1>
        
    </section>


    <section class="content">

         <!-- Content Wrapper. Contains page content -->
         <div class="box-body ">
            <table id="example" class="display nowrap " style="width:100%">
                <thead>
                    <tr>
                      <th>Número</th>
                      <th>Fecha de solicitud</th>
                      <th>Lugar de salida</th>
                      <th>Lugar de llegada</th>
                      <th>Fecha llegada</th>
                      <th>Hora Llegada</th>
                      <th>Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php if($traslados->count()): ?>  
                      <?php $__currentLoopData = $traslados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traslado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                      <tr>
                        <td><?php echo e($traslado->id); ?></td> <!--Datos de la reservacion -->
                        <td><?php echo e(date("d\-m\-Y", strtotime($traslado->fecha_hora_reserva))); ?></td>
                      <td><?php echo e($traslado->lugar_salida); ?></td>
                      <td><?php echo e($traslado->lugar_llegada); ?></td>
                        <td> <?php echo e($traslado->fecha_llegada_solicitada); ?></td>
                        <td><?php echo e($traslado->hora_llegada); ?></td>
                        <td>  
                          <a href="<?php echo e(route('calculo_costos_traslado',['id_sol_traslado' => $traslado->id])); ?>" class="btn btn-warning btn-sm">seleccionar </a>

                      </td>
                        
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                       <?php endif; ?>
                    </tbody>
                  </table>
                </div>

              </div>
     </section>   
     <?php $__env->stopSection(); ?>

     <?php $__env->startSection('scripts'); ?>
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
     <script>
     $(document).ready(function() {
          $('#example').DataTable( {
            "scrollY":"400px",
            "scrollX": true,
            "language": {
              "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
            }
            
          } );
      } );

     </script>

 <?php $__env->stopSection(); ?>
</body>
</html>
  
  
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/gerente/reservaciones/inicioTraslado.blade.php ENDPATH**/ ?>