<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Reservaciones</title>
  <script src="https://ajax.googleapis.com/ajax/libs/d3js/5.9.0/d3.min.js"></script>
</head>
<body>
<?php $__env->startSection('contenido'); ?>
  <section class="content-header"><h1>Panel de administración | <small>Reservaciones</small></h1></section>
  <section class="content">
    <?php if($alquiler->estatus=='cancelado'): ?>
    <div class="alert alert-warning alert-dismissible"><h4>¡Reservación cancelada!</h4></div>
    <?php endif; ?>
    <?php if($alquiler->estatus=='terminado'): ?>
    <div class="alert alert-warning alert-dismissible"><h4>¡Alquiler terminado!</h4></div>
    <?php endif; ?> 
    <?php if($vehiculo->estatus=='MANTENIMIENTO'): ?>
    <div class="alert alert-warning alert-dismissible"><h4>¡El vehículo se encuentra en mantenimiento!</h4></div>
    <?php endif; ?>
    <?php if($vehiculo->estatus=='INACTIVO'): ?>
    <div class="alert alert-warning alert-dismissible"><h4>¡Vehiculo se encuentra inactivo!</h4></div>
    <?php endif; ?>    
<div class="row">
    <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title"><?php echo e('Detalle Reservación'); ?> <b><?php echo e($reservacion->id); ?></b></h3>
            </div>
            <div class="box-body">
<div class="row">
<div class="col-md-6">
    <h4>Datos del <a href="">cliente </a></h4>
            <div class="col-md-6">
                <label><?php if($cliente->credencial==null): ?>
                            Pasaporte
                        <?php else: ?>
                            Identificación
                        <?php endif; ?> cliente</label>
                    <input type="text" name="cliente" id="" class="form-control" disabled value=<?php if($cliente->credencial==null): ?>
                                                                                                    <?php echo e($cliente->pasaporte); ?>

                                                                                                <?php else: ?>
                                                                                                    <?php echo e($cliente->credencial); ?>

                                                                                                <?php endif; ?>>
            </div>
            <div class="col-md-6 form-group">
                <label>Nombre cliente</label>
                <input type="text" name="cliente" id="" class="form-control" disabled value="<?php echo e($cliente->nombre); ?> <?php echo e($cliente->primer_apellido); ?> <?php echo e($cliente->segundo_apellido); ?>">  
            </div>
            <div class="col-md-4 form-group">
                <label>Nacionalidad</label>
                <input type="text" name="cliente" id="" class="form-control" disabled value="<?php echo e($cliente->pais); ?>">  
            </div>
            <div class="col-md-2 form-group">
                <label>Edad</label>
                <input type="text" name="cliente" id="" class="form-control" disabled value="<?php echo e($edad); ?>">  
            </div>
            <div class="col-md-6 form-group">
                <label>Correo</label>
                <input type="text" name="cliente" id="" class="form-control" disabled value="<?php echo e($cliente->correo); ?>">  
            </div>
    <h4 ><br>Datos de la reservación</h4>
            <div class="col-md-6">
                <label>Fecha Reservación</label>
                <input type="text" name="fecha Reservacion" id="" class="form-control" disabled 
                value="<?php echo e(date("d\-m\-Y", strtotime($reservacion->fecha_reservacion))); ?>">
            </div>
            <div class="col-md-6  form-group">
                <label>Precio Total</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e(number_format($reservacion->total,2)); ?>">
            </div>
            <?php if($reservacion->saldo==0): ?>
                <h3>Se pagó el total de la reservación</h3>
            <?php endif; ?> 
            <div class="col-md-6 form-group">
                <label>Saldo</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e(number_format($reservacion->saldo,2)); ?>">
            </div>
            <div class="col-md-7">
                <button type="button" class="btn btn-sucess" data-toggle="modal" data-target="#cobros">
                <b>Ver cobros </b>
                </button>
            </div>
            <div class="col-md-4">
                <button type="button" class="btn btn-sucess" data-toggle="modal" data-target="#reembolso">
                <b>Ver reembolso </b>
                </button>
            </div>
</div>
<div class="col-md-6">
            <h4 >Datos del <a href="">vehículo </a></h4> 
            <div class="col-md-6 form-group">
                <label>Tipo</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e($vehiculo->tipo); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Modelo</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e($vehiculo->marca); ?> <?php echo e($vehiculo->modelo); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Vin</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e($vehiculo->vin); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Placas</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e($vehiculo->matricula); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Fecha Entrega</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e(date("d\-m\-Y", strtotime($alquiler->fecha_recogida))); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Hora</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e($alquiler->hora_recogida); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Fecha Devolución</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e(date("d\-m\-Y", strtotime($alquiler->fecha_devolucion))); ?>">
            </div>
            <div class="col-md-6 form-group">
                <label>Hora</label>
                <input type="text" name="nombre" id="" class="form-control" disabled value="<?php echo e($alquiler->hora_recogida); ?>">
            </div>
            <div class="col-md-2 form-group">
                    <?php if($alquiler->estatus!='terminado'&&$alquiler->estatus!='cancelado'&&$alquiler->estatus!='en curso'): ?>
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-warning4">
                        <b>Cambiar VEHÍCULO</b>
                    </button>
                    <?php else: ?>
                    <button type="button" class="btn btn-danger" data-toggle="modal"  disabled data-target="">
                        <b>Cambiar VEHÍCULO</b>
                        <?php endif; ?>
            </div>
    </div>
</div>
 
<div class="row">
    <div class="col-md-6">
        <h4 ><br>Datos del conductor</h4>
        <form id="datos" >
            <?php echo csrf_field(); ?>
            <input type="text" name="reservacion"  style="display: none" value= "<?php echo e($reservacion->id); ?>">
            <input type="text" name="alquiler"  style="display: none" value= "<?php echo e($alquiler->id); ?>">
            <div class="col-md-6 form-group">
                <label>Número Licencia</label>
                <input type="text" name="numero" id="numero" class="form-control" title="Escriba numero de licencia"  required value=<?php if($alquiler->num_licencia == "por rellenar"): ?>
                                                                                                                                        <?php echo e(null); ?>

                                                                                                                                    <?php else: ?>
                                                                                                                                        <?php echo e($alquiler->num_licencia); ?>

                                                                                                                                    <?php endif; ?>>
                <span id="errornumero" class="glyphicon glyphicon-remove form-control-feedback" style="color:red;display: none;"></span>
                <span id="validonumero" class="glyphicon glyphicon-ok  form-control-feedback" style="color:green;display: none;"></span>
            </div>
            <div class="col-md-6 form-group">
                <label>Nombre conductor</label>                       
                <input type="text" name="nombre" id="nombre" class="form-control" required value=<?php if($alquiler->nombreConductor == "por rellenar"): ?>
                                                                                            <?php echo e(null); ?>

                                                                                        <?php else: ?>
                                                                                            <?php echo e($alquiler->nombreConductor); ?>

                                                                                        <?php endif; ?>>                   
                <span id="errornombre" class="glyphicon glyphicon-remove form-control-feedback" style="color:red;display: none;"></span>
                <span id="validonombre" class="glyphicon glyphicon-ok  form-control-feedback" style="color:green;display: none;"></span>
            </div> 
            <div class="col-md-6 form-group">
                <label>Fecha expedición</label>                        
                <input type="date" name="fecha_e" id="fecha_e" class="form-control"  value="<?php echo e(date($alquiler->expedicion_licencia)); ?>"  onblur="validar_fecha();">
                
                <span id="errorfecha_e" class="glyphicon glyphicon-remove form-control-feedback" style="color:red;display: none;"></span>
                <span id="validofecha_e" class="glyphicon glyphicon-ok  form-control-feedback" style="color:green;display: none;"></span>
            </div>
                
            <div class="col-md-6 form-group">
                <label>Fecha expiración</label>
                <input type="date" name="fecha_c" id="fecha_c" class="form-control"  value="<?php echo e(date($alquiler->expiracion_licencia)); ?>"  onblur="validar_fecha();">

                <span id="errorfecha_c" class="glyphicon glyphicon-remove form-control-feedback" style="color:red;display: none;"></span>
                <span id="validofecha_c" class="glyphicon glyphicon-ok  form-control-feedback" style="color:green;display: none;"></span>
            </div>
            <?php if($alquiler->estatus!='terminado'&&$alquiler->estatus!='cancelado'&&$alquiler->estatus!='en curso'): ?>
            <button type="submit" id="enviar" class="btn btn-primary pull-right">Agregar</button>
            <?php endif; ?>
        </form>
    </div>

    <div clas="col-md-6">
        <h4 ><br>Servicios Extras Reservados </h4>.
        <div class="col-md-6 form-group">
            <table class="table table-striped table-dark">
                <body>
                    <th>Nombre</th><th>Descripción</th>
                    <?php if($servicios->count()): ?>  
                        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr><td><?php echo e($servicio->nombre); ?></td><td><?php echo e($servicio->descripcion); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr><td>No hay extras reservados!</td></tr>
                    <?php endif; ?>
                </body>
            </table>
        </div>
    </div>

    <div class="col-md-11">
        <div class="box-footer" style="float: right">
            <?php if($alquiler->estatus=="pendiente_recogida"): ?>
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-warning"><b>Cancelar</b></button>
            <?php if($vehiculo->estatus=='ACTIVO'&&$alquiler->nombreConductor!="por rellenar"&&$alquiler->expedicion_licencia!="por rellenar"&&$alquiler->num_licencia!="por rellenar"&&$alquiler->expiracion_licencia!="por rellenar"&&$alquiler->estatus!='en curso'&&date("Y-m-d")>=$alquiler->fecha_recogida): ?>
                <a href="<?php echo e(route('contrato', $reservacion)); ?>" class="btn btn-success"><b>Entregar</b></a>
            <?php endif; ?>
            <?php elseif($alquiler->estatus=="en curso"): ?>
                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#recibir"><b>Recibir</b></button>
            <?php endif; ?>
        </div>                       
    </div>  

</div>        
 <!-- ----------------------------------------------------------------------seccion de modales----------------------------------------------------------------------------- -->
        <div class="modal modal-danger fade" id="modal-warning">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"> <span class="glyphicon glyphicon-alert"></span> <b> <?php echo e(' Esta seguro de cancelar la reservacion'); ?>  <?php echo e($reservacion->id); ?></b> </h4>
                </div>
                <div class="modal-body">
                  <p><b><?php echo e('La reservación del servicio de alquiler y sus servicios extra serán cancelados'); ?> </b>&hellip;</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-arrow-left"></span><b><?php echo e('  Cerrar'); ?></b></button>
                  <form method="GET" action="<?php echo e(route('cancelaReservacion',$reservacion->id)); ?>"  role="form">
                      <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-info-sign"></span><?php echo e('  Cancelar'); ?></button>
                  </form>
                </div>
              </div>
              <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
          </div>

        <div class="modal modal-warning fade" id="registrar_reintegro">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"> <span class="glyphicon glyphicon-usd"></span> <b> <?php echo e('Registrar reembolso'); ?></b> </h4>
                </div>
            <form method="POST" action="<?php echo e(route('reembolsoReservacion')); ?>"  role="form" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <input name="reservacion" type="hidden" value= "<?php echo e($reservacion->id); ?>">
                    <p><b><?php echo e('Se registrará un nuevo reembolso'); ?> </b>&hellip;</p>
                    <div class="row"> 
                        <div class="col-md-3">
                            <label>Motivo</label>
                            <select name= "motivo" id="motivo" class="form-control select2" style="width: 100%;">
                            <option value="otro">Otro</option>
                            <option value="cambio de vehiculo">Cambio de vehiculo</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label>Datos</label>
                            <input type="text" name="datos" id="" class="form-control"  value="">
                        </div>
                        <div class="col-md-3">
                            <label>Monto</label>
                            <input type="number" name="monto" id="" class="form-control"  value="">
                        </div>
                        <div class="col-md-9">
                            <label>Comentario</label>
                            <input type="text" name="comentario" id="" class="form-control"  value="">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-info-sign"></span><?php echo e(' Registrar reembolso'); ?></button>
                </div>
            </form>
              </div>
              <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="modal modal-fade-in" id="cobros">
            <div class="modal-dialog">
                <div class="modal-content modal-lg">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title"> <b> <?php echo e('Gestión de cobros'); ?></b> </h4>
                    </div>
                    <div class="modal-body">
                      <div class="col-md-12 col-md-offset-3">
                        <div clas="row"> 
                            <h4> <b> <?php echo e('Registrar nuevo cobro:'); ?></b> </h4>
                        </div>
                      <form method="POST" action="<?php echo e(route('pagoReservacion')); ?>"  role="form" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input name="reservacion" type="hidden" value= "<?php echo e($reservacion->id); ?>">
                        <div clas="row"> 
                            <div class="col-md-8">
                                <div class="col-md-3"><label>Motivo</label></div>
                                <div class="col-md-5">
                                    <select name= "motivo" id="motivo" class="form-control select2" style="width: 100%;">
                                        <option value="otro">Otro</option>
                                        <option value="reparacion">Reparacion</option>
                                        <?php if($reservacion->saldo!=0): ?>
                                            <option value="saldo">Saldo</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div clas="row">
                            <div class="col-md-8">
                                <div class="col-md-3"><label>Metodo</label></div>
                                <div class="col-md-5">
                                    <select name= "metodo" id="metodo" class="form-control select2" style="width: 100%;">
                                        <option value="efectivo">Efectivo</option>
                                        <option value="t. credito">Tarjeta/credito</option>
                                        <option value="t. debito">Tarjeta/debito</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div clas="row">
                            <div class="col-md-8">
                                <div class="col-md-3"><label>Id/datos</label></div>
                                <div class="col-md-5">
                                <input type="text" name="datos" id="" class="form-control"  value="">
                                </div>
                            </div>
                        </div>
                        <div clas="row">
                            <div class="col-md-8">
                                <div class="col-md-3"><label>Monto</label></div>
                                <div class="col-md-5">
                                    
                                    <input type="number" name="monto" id="" class="form-control"  value="" min="100" max="1000000">
                                    
                                </div>
                            </div>
                        </div>
                        <div clas="row">
                            <div class="col-md-8">
                                <div class="col-md-3"><label>Comentario</label></div>
                                <div class="col-md-5">
                                    <input type="text" name="comentario" id="" class="form-control"  value="">
                                </div>
                            </div>
                        </div>
                    </div>
                        <div clas="row">
                        <button type="submit" class="btn btn-success pull-right"><span class="glyphicon glyphicon-info-sign"></span><?php echo e('Registrar cobro'); ?></button>
                </form>
                        </div>
                    <div clas="row"></div>
                    <div clas="row">
                   
                    <button type="submit" class="btn btn-success pull-right"><span class="glyphicon glyphicon-info-sign"></span><?php echo e('Registrar cobro'); ?></button>
                  </form>
               
                </div>


                <div clas="row">
               
                </div>
                <div clas="row">
                    <div class="col-md-12 col-xs-offset-3">
                    <h4> <b> <?php echo e('Registro de cobros:'); ?></b> </h4>
                    <br>
                  </div>
                    <div class="col-md-12">
                        <div class="form-group">

                    
                          <table class="table table-striped table-dark">
                            <th>Número</th>
                            <th>Datos del cobro</th>
                            <th>Motivo</th>
                            <th>Fecha</th>
                            <th>Monto</th>
                            <th>Comentario</th>
                            <?php if($pagos->count()): ?>  
                            <input id="dec" name="dec" type="hidden" value= <?php echo e($total = 0.0); ?>  >
                           
                            <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input id="total" name="total" type="hidden" value=<?php echo e($total+=$pago->total); ?>  >
                            <tr>
                            <td><?php echo e($pago->id); ?></td>
                        
                              <td> <?php echo e($pago->paypal_Datos); ?>

 
                              <?php echo e($pago->mostrador_Datos); ?> 
                                                        </td>
                                <td><?php echo e($pago->motivo); ?></td>

                                    <td><?php echo e(date("d\-m\-Y", strtotime($pago->fecha))); ?></td>

                                    <td><?php echo e(number_format($pago->total,2)); ?></td>
                                    <td><?php echo e($pago->comentario); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </table>
                                <h3>Total cobrado = $<?php echo e($total); ?></h3>
                            </div>
                        </div>

                    </div>

</div>

                      <div class="modal-footer">
                      </div>
                  </div>
              </div>
          </div>

            <div class="modal modal-warning fade" id="modal-warning4"><!--MODAL CAMBIO DE VEHICULO -->

                <div class="modal-dialog">
                  <div class="modal-content">

                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title"> <span class="glyphicon glyphicon-warning"></span> <b> <?php echo e('Cambio de vehículo para la reservación '); ?>  <?php echo e($reservacion->id); ?></b> </h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="row">
                              <div class="col-md-12 ">
                                <div class="form-group">
                                  <label> Atención un vehículo no debe de cambiarse de una reservación a menos que sea por motivo de siniestro o fallo para llevar a mantenimiento<br> <br><br>A continuación se enlistan los vehículos disponibles en la sucursal para el periodo de renta </label>
                                <form action="<?php echo e(route('cambia_Vehiculo')); ?>" method="" enctype="multipart/form-data">
                                    <input name="reservacion" type="hidden" value= "<?php echo e($reservacion->id); ?>">
                                  <select name= "vehiculo" id="vehiculo" class="form-control select2" style="width: 100%;">
                                    <?php if(count($disponibles)>0): ?>
                                        <?php for($i = 0;$i<count($disponibles); $i++): ?>

                                        <option value = <?php echo e($disponibles[$i]->idvehiculo); ?>>Tipo: <?php echo e($disponibles[$i]->tipo); ?>  <?php echo e($disponibles[$i]->marca); ?> <?php echo e($disponibles[$i]->modelo); ?> Placas: <?php echo e($disponibles[$i]->matricula); ?></option>
                                        <?php endfor; ?>
                                      <?php else: ?>
                                      <option value=""> No hay vehículos disponibles</option>

                                       <?php endif; ?>
                                  </select>
                            
                                
                                </div>
                              </div>
                            </div>
                          </div>
                            
                      <p><b><?php echo e('Se cambiará el vehículo de la reservación '); ?> <?php echo e($reservacion->id); ?> <?php echo e(' '); ?> </b>&hellip;</p>
                    </div>
                    <div class="modal-footer">
                        <?php if(count($disponibles)>0): ?>
                        <button class="btn btn-primary" type="submit">Cambiar vehículo</button>
                        <?php else: ?>
                        <button class="btn btn-primary" type="" disabled>Cambiar vehículo</button>
                        <?php endif; ?>
                    </div>
                    </form>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>


<!--MODAL REEMBOLSOS-->
<div class="modal fade in" id="reembolso">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"> <b> <?php echo e('Gestión de reembolsos'); ?></b> </h4>
            </div>

            <div class="modal-body">
                <div class="col-md-12 col-md-offset-3">
              <div clas="row"> 
                <h4> <b> <?php echo e('Registrar nuevo reembolso:'); ?></b> </h4>
              </div>
              <form method="POST" action="<?php echo e(route('reembolsoReservacion')); ?>"  role="form" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input name="reservacion" type="hidden" value= "<?php echo e($reservacion->id); ?>">
              <div clas="row"> 
                  <div class="col-md-8">
                      <div class="col-md-3">
                      <label>Motivo</label>
                      </div>
                      <div class="col-md-5">
                             <select name= "motivo" id="motivo" class="form-control select2" style="width: 100%;">
                        <option value="otro">Otro</option>
                        <option value="reparacion">Retraso</option>
                    </select>
                  </div>
                  </div>
                </div>



                  <div clas="row">
                      <div class="col-md-8">
          <div class="col-md-3">
              <label>Dato</label>
              </div>

              <div class="col-md-5">
              <input type="text" name="datos" id="" class="form-control"  value="">
            </div>
          </div>
            </div>

            <div clas="row">
                <div class="col-md-8">
              <div class="col-md-3">
              <label>Monto</label>
              </div>
              <div class="col-md-5">
              
              <input type="number" name="monto" id="" class="form-control"  value="" min="100" max="1000000">
              
            </div>
              </div>
            </div>
         
            <div clas="row">
                <div class="col-md-8">
                    <div class="col-md-3">
                    <label>Comentario</label>
                    </div>
            <div class="col-md-5">
                <input type="text" name="comentario" id="" class="form-control"  value="">
              </div>
                </div>
              </div>

            </div>

            <div clas="row">

            <button type="submit" class="btn btn-success pull-right"><span class="glyphicon glyphicon-info-sign"></span><?php echo e('Registrar reembolso'); ?></button>
          </form>
          
        </div>

        <div clas="row">
               
          </div>


        <div clas="row">
            <div class="col-md-12 col-xs-offset-3">
            <h4> <b> <?php echo e('Registro de reembolsos:'); ?></b> </h4>
            <br>
          </div>
          <div class="col-md-11" style="margin-left: 5%;">
                <div class="form-group">
                    <input id="dec" name="dec" type="hidden" value=<?php echo e($totalr = 0.0); ?> >
                    <table class="table table-striped table-dark">
                        <th>Número</th>
                        <th>Datos</th>
                        <th>Motivo</th>
                        <th>Fecha</th>
                        <th>Monto</th>
                        <th>Comentario</th>
                        <?php if($reembolsos->count()): ?>  
                        <?php $__currentLoopData = $reembolsos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reembolso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input id="total" name="total" type="hidden" value=<?php echo e($totalr+=$reembolso->total); ?>>
                        <tr>
                        <td><?php echo e($reembolso->id); ?></td>
                    
                          <td> <?php echo e($reembolso->paypal_Datos); ?>

  
                          <?php echo e($reembolso->mostrador_Datos); ?> 
                                                    </td>
                            <td><?php echo e($reembolso->motivo); ?></td>
  
                           <td><?php echo e(date("d\-m\-Y", strtotime($reembolso->fecha))); ?></td>
  
                          <td><?php echo e(number_format($reembolso->total,2)); ?></td>
                          <td><?php echo e($reembolso->comentario); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
  
                      </table>
                    <h3>Total pagado =$<?php echo e($totalr); ?></h3>
                </div>
              </div>

        </div>
      </div>



              <div class="modal-footer">
              </div>
          </div>
      </div>
  </div>

<!--FIN MODAL REEMBOLSOS-->


<div class="modal fade in" id="reembolsos">

  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"> <span class="glyphicon glyphicon-warning"></span> <b> <?php echo e('Remmbolsos por la reservación'); ?>  <?php echo e($reservacion->id); ?></b> </h4>
      </div>
      <div class="modal-body">

          <div class="box-body">
              <div class="row">
                <div class="col-md-12 ">
                  <div class="form-group">

              

                  </div>
                </div>
              </div>
            </div>
              
      </div>
      <div class="modal-footer">


      </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>



                <div class="modal fade in" id="recibir">

                    <div class="modal-dialog">
                      <div class="modal-content">
    
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                          <h4 class="modal-title"> <span class="glyphicon glyphicon-warning"></span> <b> <?php echo e('Terminar renta de vehículo de reservación'); ?>  <?php echo e($reservacion->id); ?></b> </h4>
                        </div>
                        <div class="modal-body">
    
                            <div class="box-body">
                                <div class="row">
                                  <div class="col-md-12 ">
                                    <div class="form-group">
                                        <form method="GET" action="<?php echo e(route('recibir')); ?>"  role="form">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="reservacion" type="hidden" value= "<?php echo e($alquiler->id_reservacion); ?>">
                                            <input name="alquiler" type="hidden" value= "<?php echo e($alquiler->id); ?>">
                                        <div class="col-md-6 form-group">
                                            <label>Kilometraje del vehiculo</label>
                                        <input type="number" name="km" id="" class="form-control"  value="<?php echo e($vehiculo->kilometraje); ?>" min="<?php echo e($vehiculo->kilometraje); ?>">
                                          </div>

                                          <div class="col-md-6 form-group">
                                              <label>Comentario</label>
                                              <input type="text" name="comentario" id="" class="form-control"  value="">
                                            </div>
                                    
                                    </div>
                                  </div>
                                </div>
                              </div>
                                
                          <p><b><?php echo e('Se recibirá el vehículo rentado de la reservación  '); ?> <?php echo e($reservacion->id); ?> <?php echo e(' '); ?> </b>&hellip;</p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-info-sign"></span><?php echo e('Terminar'); ?></button>
                        </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
            </div>  
          </div>
        </div>
      </div>
    </div>
  </div>


  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#error" style="display: none" id="error1">Cancelar</button>
<div class="modal modal-danger fade" id="error">
    <div class="modal-dialog" >
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Error al agregar datos del conductor</b> </h4>
        </div>
        <div class="modal-body">
          <p>Verifique los campos necesarios&hellip;</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Aceptar</button>
        
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>


  <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-info" style="display: none" >

  </button>
  <div class="modal modal-info fade" id="modal-info">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">DATOS DE LICENCIA</h4>
        </div>
        <div class="modal-body">
          <p>LOS DATOS FUERON AGREGADOS CORRECTAMENTE&hellip;</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">Continuar</button>
          
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal ---->

    <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>


 
    <script>
      $(function () {
          
          $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
        });
        $(document).ready(function(){
        $('#enviar').click(function (e) {
       e.preventDefault();
        
            $.ajax({
              url: "<?php echo e(route('conductor')); ?>",
              data:$('#datos').serialize(),              
              type: "POST",
              dataType: 'json',
              success: function (data) {
               var mensaje=data.success;
                // console.log(data);
                if(mensaje=='FECHAS'){
                $('#error1').click();
                jQuery('#validofecha_e').hide(); 
                 jQuery('#errorfecha_e').show();          
                $( '#fecha_e' ).css('borderColor', 'red');
                jQuery('#validofecha_c').hide(); 
                 jQuery('#errorfecha_c').show();          
                $( '#fecha_c' ).css('borderColor', 'red');
                }
                if(mensaje=='EXITO'){
                  $('.btn-info').click();
                }
              },
              error: function (data) {
              var err = JSON.parse(data.responseText);
              var arreglo = err.errors;
              //  console.log(arreglo);
               var numero = arreglo.numero;
               var nombre = arreglo.nombre;
               var fecha_e = arreglo.fecha_e;
               var fecha_c = arreglo.fecha_c;
             
     
               
               if (numero == undefined){  
                 $( '#numero' ).css('borderColor', 'green');         
                 jQuery('#validonumero').show(); 
                 jQuery('#errornumero').hide(); 
                 }else{
                   jQuery('#validonumero').hide(); 
                 jQuery('#errornumero').show();          
                $( '#numero' ).css('borderColor', 'red'); 
               }
     
           
               if (nombre == undefined){  
                 $( '#nombre' ).css('borderColor', 'green');         
                 jQuery('#validonombre').show(); 
                 jQuery('#errornombre').hide(); 
                 }else{
                   jQuery('#validonombre').hide(); 
                 jQuery('#errornombre').show();          
                $( '#nombre' ).css('borderColor', 'red');
                 
               }


               if (fecha_e == undefined){  
                 $( '#fecha_e' ).css('borderColor', 'green');         
                 jQuery('#validofecha_e').show(); 
                 jQuery('#errorfecha_e').hide(); 
                 }else{
                   jQuery('#validofecha_e').hide(); 
                 jQuery('#errorfecha_e').show();          
                $( '#fecha_e' ).css('borderColor', 'red');
                 
               }
     
               if (fecha_c == undefined){  
                 $( '#fecha_c' ).css('borderColor', 'green');         
                 jQuery('#validofecha_c').show(); 
                 jQuery('#errorfecha_c').hide(); 
                 }else{
                   jQuery('#validofecha_c').hide(); 
                 jQuery('#errorfecha_c').show();          
                $( '#fecha_c' ).css('borderColor', 'red');
                 
               }              
                $('#enviar').html('guardar cambios');
                   $('#error1').click();
              }
          });
        });     
      });
           });

           function validar_fecha(){
        var expedicion = document.getElementById("fecha_e").value;
        var vencimiento = document.getElementById("fecha_c").value;
        //--------------
        console.log(expedicion);
        console.log(expedicion);
        var expedicion  = new Date(expedicion);
        var vencimiento = new Date(vencimiento);
        var hoy =  new Date();
    if(expedicion != null && vencimiento != null){
        if(vencimiento < expedicion ){
            alert("Fecha invalida!! La fecha de vencimiento no puede ser menor a la de expedición");
            document.getElementById("fecha_e").value = null;
            document.getElementById("fecha_c").value = null;
        }
        if(expedicion > hoy){
            alert("Licencia de conducir no existente");
            document.getElementById("fecha_e").value = null;
            document.getElementById("fecha_c").value = null;
        }
        if(vencimiento < hoy){
            alert("La licencia ya vencio");
            document.getElementById("fecha_e").value = null;
            document.getElementById("fecha_c").value = null;
        }
    }
                
    };
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/gerente/reservaciones/detalle.blade.php ENDPATH**/ ?>