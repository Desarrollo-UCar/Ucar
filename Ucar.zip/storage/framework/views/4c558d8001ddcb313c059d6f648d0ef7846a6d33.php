<footer class="main-footer">
    <!-- <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Ü-Car&copy; 2019 <a href="https://adminlte.io">& Instituto Tecnologico de Oaxaca/Deprtamento de Sistemas y Computacion</a>.</strong> All rights reserved. -->
</footer><?php /**PATH C:\laragon\www\Ucar\resources\views/theme/lte/footer.blade.php ENDPATH**/ ?>