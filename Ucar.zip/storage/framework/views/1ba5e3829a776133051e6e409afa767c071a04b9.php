<!doctype html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <title>Ü-car Renta de vehículos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
    </style>
</head>
<body>
<section id="content">
<div class="container">

            <div class="row border border-primary">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12"> <b style="color: dodgerblue">Ü-Car</b> <h1 class = "text-primary">Solicitud de traslado. El folio de tu solicitud de traslado es: <strong><?php echo e($solicitud_traslado->id); ?></strong></h1></div>
                    <div style="float:left;">
                        <div id="lista_itinerario">
                            <h2><strong>-------Datos de Contacto: -------</strong></h2>       
                            <ul>
                            <li>nombre</dt>
                            <dd><?php echo e($solicitud_traslado->nombres); ?> <?php echo e($solicitud_traslado->primer_apellido); ?> <?php echo e($solicitud_traslado->segundo_apellido); ?>

                            <li>Teléfono:</dt>
                            <dd><?php echo e($solicitud_traslado->telefono); ?></dd>
                            <li>Email:</dt>
                            <dd><?php echo e($solicitud_traslado->email); ?></dd>
                            </ul> 
                        </div>
                    </div>
                    <div style="float:left;">
                        <div id="lista_itinerario">
                            <h2><strong>------- Datos Generales: -------</strong></h2>       
                            <ul>
                            <li><strong>**Viaje Redondo**</strong></dt>
                            <dd><?php echo e($solicitud_traslado->dias_espera); ?> Dias de espera</dd>
                            <li>Origen</dt>
                            <dd><?php echo e($solicitud_traslado->lugar_salida); ?></dd>
                            <li>Fecha / Hora de recolección:</dt>
                            <dd><?php echo e($solicitud_traslado->fecha_salida); ?> a las <?php echo e($solicitud_traslado->hora_salida); ?> hrs</dd>
                            <li>Destino</dt>
                            <dd><?php echo e($solicitud_traslado->lugar_llegada); ?></dd>
                            <li>Fecha / Hora de recolección:</dt>
                            <dd><?php echo e($solicitud_traslado->fecha_llegada_solicitada); ?> a las <?php echo e($solicitud_traslado->hora_llegada); ?> hrs</dd>
                            <li>Número de pasajeros:</dt>
                            <dd><?php echo e($solicitud_traslado->n_pasajeros); ?> Pasajeros</dd>
                            </ul> 
                        </div>
                    </div>
                    <div style="float:left;">
                            <div id="lista_itinerario">
                                <h2><strong>------- Cotización: -------</strong></h2>       
                                <ul>
                                <li><strong>**Estos son tus cobros**</strong></dt>
                                <li>Renta del automovil</dt>
                                <dd><?php echo e($vehiculo->precio); ?></dd>
                                <li>Servicio de chofer:</dt>
                                <dd><?php echo e($solicitud_traslado->n_choferes); ?> ? Choferes por viaje por <?php echo e($dias); ?> dias</dd>
                                <li>Subtotal</dt>
                                <dd><?php echo e($subtotal); ?>--MXN</dd>
                                <li>Descuento de:</dt>
                                <dd><?php echo e($solicitud_traslado->descuento * $subtotal); ?>--MXN</dd>
                                <li>Total a pagar:</dt>
                                <dd><?php echo e($total); ?>--MXN</dd>
                                </ul> 
                            </div>
                        </div>

                </div>
    </div>
    </section>
</body>
</html><?php /**PATH C:\laragon\www\Ucar\resources\views/mails/confirmacion_traslado.blade.php ENDPATH**/ ?>