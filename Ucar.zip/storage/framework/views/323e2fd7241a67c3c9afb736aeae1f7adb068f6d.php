<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Clientes</title>
 
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/tabla.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css')); ?>">
 </head>
<body>
  
<?php $__env->startSection('contenido'); ?>
    <section class="content-header">
        <h1>
          Panel de administración |
          <small>Clientes</small>
        </h1>
        
    </section>


         <!-- Content Wrapper. Contains page content -->
 
         <?php //$clientes = DB::table('clientes')->get(); ?>

    <!-- Main content -->
    <section class="content">

        <div class="row">
           
            <!-- Left col -->
            <section class="col-lg-12 connectedSortable">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="nav-tabs-custom">
                <!-- Tabs within a box -->
                <ul class="nav nav-tabs pull-right">
                    <div class="btn-group pull-right" >
                        <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" >
                          Mas opciónes
                          <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu">
                          <li><a href="#" id="frecuentes" onclick="mostrar()"><b>clientes frecuentes</b></a></li>
                          <li><a href="#" onclick="ingresos()"><b>Por ingresos</b></a></li>
                        </ul>
                      </div>
                  <li class="pull-left header"><i class="fa fa-inbox"></i>Clientes </li>
                </ul>
                <div class="tab-content no-padding">
                  <!-- Morris chart - Sales -->
                  <div class="chart tab-pane active" id="revenue-chart" style="position: relative; height:auto;">
                      <form action="<?php echo e(route('showcliente')); ?>" method="POST" enctype="multipart/form-data" >
                    <div class="col-md-6 col-xs-offset-6" id="clifre" style="display: none;">
                                                <div class="col-md-6 form-group">
                              <label>Fecha inicial</label>
                                  <input type="date" name="fecha_inicio" id="" class="form-control" autofocus>
                          </div>
                          <div class="col-md-6 form-group">
                              <label>Fecha final</label>
                                  <input type="date" name="fecha_final" id="" class="form-control" autofocus>
                          </div>
                          <div class="box-footer" style="float: right">
                              <button type="submit" class="btn btn-primary">Consultar</button>
                            </div>
                            <div class="box-footer" style="float: right">
                                <a href="#" class="btn btn-danger" onclick="deshabilitar()">Cancelar</a>
                              
                              </div>                   

                    </div>
                  </form>

                  <form action="<?php echo e(route('mantenimiento.store')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                    <div class="col-md-6 col-xs-offset-6" id="ingresos1" style="display: none;">
                       
                            <div class="col-md-6 form-group">
                                <label>Cantidad inicial</label>
                                <input type="number" step="0.00" name="cant_inicial" id="" min="0.00" class="form-control" value="0.00"  required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Cantidad final</label>
                                <input type="number" step="0.00" name="costo_final" id="" min="0.00" class="form-control" value="0.00" required>
                            </div>
                            <div class="box-footer" style="float: right">
                                <button type="submit" class="btn btn-primary">Consultar</button>
                              </div>
                              <div class="box-footer" style="float: right">
                                  <a href="#" class="btn btn-danger" onclick="deshabilitaringresos()">Cancelar</a>
                                
                                </div>
                                                              
                        
  
                      </div>
                    </form>
                    
                      <?php if(count($clientes)==0): ?>
                      <div style="display: none;">
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-warning" id="<?php 
                        echo "boton";
                      ?>">
                          </button>
                        </div>
                        <?php endif; ?> 

                        <table id="example" class="display nowrap " style="width:100%">
                            <thead>
                                <tr>
                                    <th style="text-align: center;background: lightblue">Identificación/Pasaporte</th>
                                    <th style="text-align: center;background: lightblue">Nombre</th>
                                    <th style="text-align: center;background: lightblue">Apellido Paterno</th>                              
                                    <th style="text-align: center;background: lightblue">Apellido Materno</th>   
                                    <th style="text-align: center;background: lightblue">Fecha Nacimiento</th>
                                    <th style="text-align: center;background: lightblue">Nacionalidad</th>
                                    <th style="text-align: center;background: lightblue">Correo</th>
                                    <th style="text-align: center;background: lightblue">Teléfono</th>
                                    <th style="text-align: center;background: lightblue">País</th>
                                    <th style="text-align: center;background: lightblue">Estado</th>
                                    <th style="text-align: center;background: lightblue">Ciudad</th>
                                    <th style="text-align: center;background: lightblue">Colonia</th>
                                    <th style="text-align: center;background: lightblue">Calle</th>
                                    <th style="text-align: center;background: lightblue">Fecha Alta</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                            <tr>
                                  <?php if($cliente->credencial==null): ?>
                                  <td style="text-align: center"><?php echo e($cliente->pasaporte); ?></td>
                                  <?php else: ?>
                                  <td style="text-align: center"><?php echo e($cliente->credencial); ?></td>
                                  <?php endif; ?> 
                                 
                              <td style="text-align: center"><?php echo e($cliente->nombre); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->primer_apellido); ?></td>
                              <?php if($cliente->segundo_apellido==null): ?>
                              <td style="text-align: center">---------</td>
                              <?php else: ?>
                              <td style="text-align: center"><?php echo e($cliente->segundo_apellido); ?></td>
                              <?php endif; ?> 
                              <td style="text-align: center"><?php echo e(date("d\-m\-Y", strtotime($cliente->fecha_nacimiento))); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->nacionalidad); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->correo); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->telefono); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->pais); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->estado); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->ciudad); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->colonia); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->calle); ?></td>
                              <td style="text-align: center"><?php echo e($cliente->created_at); ?></td>
                            </tr> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </tbody>
                        </table>
                  </div>


                
                </div>
              </div>
            </div>          
      </section>
   
      <div class="modal modal-warning fade" id="modal-warning">
          <div class="modal-dialog" >
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">No se encuentra ningún registro. :( </b> </h4>
              </div>
              <div class="modal-body">
                <p>Espera que un cliente se de Alta en el sistema.&hellip;</p>
              </div>
              <div class="modal-footer">
                
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-success pull-left">Regresar</a>
              <a href="<?php echo e(URL::previous()); ?>"  class="btn btn-primary">Continuar</a>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>



   
<?php $__env->stopSection(); ?>    
     <?php $__env->startSection('scripts'); ?>

     <script>           
        $(document).ready(function() {

         var obj= document.getElementById("boton");
         obj.click();
         } );
        </script>

        <script>
        function mostrar(){
document.getElementById('clifre').style.display = 'block';
document.getElementById('ingresos1').style.display = 'none';
}

function deshabilitar(){
document.getElementById('clifre').style.display = 'none';
}

function ingresos(){
document.getElementById('clifre').style.display = 'none';
document.getElementById('ingresos1').style.display = 'block';
}

function deshabilitaringresos(){
document.getElementById('ingresos1').style.display = 'none';
}
        </script>

         <script>
         $(document).ready(function() {
              $('#example').DataTable( {
                "scrollY": "400px",
                "scrollX": true,
                "language": {
                  "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
                }
                
              } );
          } );
         </script>
         <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
         <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
     <?php $__env->stopSection(); ?>
</body>
</html>
  
  

<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/gerente/clientes/ver_clientes.blade.php ENDPATH**/ ?>