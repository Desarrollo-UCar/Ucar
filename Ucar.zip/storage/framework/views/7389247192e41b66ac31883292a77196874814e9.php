<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Registrarme')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="primer_apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Primer apellido')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="primer_apellido" type="text" class="form-control <?php if ($errors->has('primer_apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('primer_apellido'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="primer_apellido" value="<?php echo e(old('primer_apellido')); ?>" required autocomplete="primer_apellido" autofocus>
    
                                    <?php if ($errors->has('primer_apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('primer_apellido'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="segundo_apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Segundo apellido')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="segundo_apellido" type="text" class="form-control <?php if ($errors->has('segundo_apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('segundo_apellido'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="segundo_apellido" value="<?php echo e(old('segundo_apellido')); ?>" required autocomplete="segundo_apellido" autofocus>
    
                                    <?php if ($errors->has('segundo_apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('segundo_apellido'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="nacionalidad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nacionalidad')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="nacionalidad" type="text" class="form-control <?php if ($errors->has('nacionalidad')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nacionalidad'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nacionalidad" value="<?php echo e(old('nacionalidad')); ?>" required autocomplete="nacionalidad" autofocus>
    
                                    <?php if ($errors->has('nacionalidad')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nacionalidad'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="INE" class="col-md-4 col-form-label text-md-right"><?php echo e(__('INE')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="INE" type="text" class="form-control <?php if ($errors->has('INE')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('INE'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="INE" value="<?php echo e(old('INE')); ?>" required autocomplete="INE" autofocus>
    
                                    <?php if ($errors->has('INE')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('INE'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="pasaporte" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pasaporte')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="pasaporte" type="text" class="form-control <?php if ($errors->has('pasaporte')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pasaporte'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pasaporte" value="<?php echo e(old('pasaporte')); ?>" required autocomplete="pasaporte" autofocus>
    
                                    <?php if ($errors->has('pasaporte')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pasaporte'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>

                        <div class="form-group row">
                                <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefono')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="telefono" type="text" class="form-control <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefono" value="<?php echo e(old('telefono')); ?>" required autocomplete="telefono" autofocus>
    
                                    <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="pais" type="text" class="form-control <?php if ($errors->has('pais')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pais'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="pais" value="<?php echo e(old('pais')); ?>" required autocomplete="pais" autofocus>
    
                                    <?php if ($errors->has('pais')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pais'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="estado" type="text" class="form-control <?php if ($errors->has('estado')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('estado'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="estado" value="<?php echo e(old('estado')); ?>" required autocomplete="estado" autofocus>
    
                                    <?php if ($errors->has('estado')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('estado'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="ciudad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ciudad')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="ciudad" type="text" class="form-control <?php if ($errors->has('ciudad')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ciudad'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="ciudad" value="<?php echo e(old('ciudad')); ?>" required autocomplete="ciudad" autofocus>
    
                                    <?php if ($errors->has('ciudad')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ciudad'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="colonia" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Colonia')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="colonia" type="text" class="form-control <?php if ($errors->has('colonia')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('colonia'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="colonia" value="<?php echo e(old('colonia')); ?>" required autocomplete="colonia" autofocus>
    
                                    <?php if ($errors->has('colonia')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('colonia'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="calle" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Calle')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="calle" type="text" class="form-control <?php if ($errors->has('calle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('calle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="calle" value="<?php echo e(old('calle')); ?>" required autocomplete="calle" autofocus>
    
                                    <?php if ($errors->has('calle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('calle'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="numero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="numero" type="text" class="form-control <?php if ($errors->has('numero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="numero" value="<?php echo e(old('numero')); ?>" required autocomplete="numero" autofocus>
    
                                    <?php if ($errors->has('numero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>
                        <div class="form-group row">
                                <label for="foto" class="col-md-4 col-form-label text-md-right"><?php echo e(__('foto')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="foto" type="text" class="form-control <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="foto" value="<?php echo e(old('foto')); ?>" required autocomplete="foto" autofocus>
    
                                    <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirma contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Registrar')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views//auth/register.blade.php ENDPATH**/ ?>