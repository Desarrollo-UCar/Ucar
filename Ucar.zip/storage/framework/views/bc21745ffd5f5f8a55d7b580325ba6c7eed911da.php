<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Mantenimiento</title>
  <script src="https://ajax.googleapis.com/ajax/libs/d3js/5.9.0/d3.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/tabla.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css')); ?>">
</head>
<body>
  
<?php $__env->startSection('contenido'); ?>
    <section class="content-header">
        <h1>
          Panel de administracion |
          <small>Mantenimiento</small>
        </h1>        
    </section>
   
    <section class="content">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">            
               Por favor de rellenar los campos correctamente
        </div>
    <?php endif; ?>
    <?php if(session()->has('msj')): ?>
    <div class="alert alert-info" role="alert"><?php echo e(session('msj')); ?></div> 
    <a href="<?php echo e(route('mantenimiento.index')); ?>" style="color:darkgreen"><b> ver todos los mantenimientos </b></a>
                                   
    <?php endif; ?> 
    <?php if(session()->has('mensaje')): ?>
    <div class="alert alert-danger" role="alert"><?php echo e(session('mensaje')); ?></div>                                    
    <?php endif; ?> 
            <div class="box box-primary">           
                <div class="box-header with-border">
                  <h3 class="box-title">Nuevo mantenimiento</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <!-- FORM PARA PREVISUALIZAR FOTO -->
                <div class="row">
                    <div class="col-md-8">
                        <form action="<?php echo e(route('mantenimiento.update',$mantenimiento->idmantenimiento)); ?>" method="POST" enctype="multipart/form-data" id="form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                                    <div class="col-md-5 form-group">
                                        <label>Sucursal</label>
                                            <input type="text" name="sucursal" id="" class="form-control" autofocus onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo e($mantenimiento->nombre); ?>" readonly>
                                    </div>

                                    <div class="col-md-4 form-group">
                                        <label>Vehículo</label>
                                            <input type="text" name="anio" id="" class="form-control" autofocus onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo e($mantenimiento->marca); ?> <?php echo e($mantenimiento->modelo); ?> <?php echo e($mantenimiento->anio); ?>" readonly>
                                    </div>

                                    <div class="col-md-3 form-group">
                                        <label>Placas</label>
                                            <input type="text" name="matricula" id="" class="form-control" autofocus onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo e($mantenimiento->matricula); ?>" readonly>
                                    </div>
                                        <hr width="90%"/>

                                    <div class="form-group col-md-3">
                                        <label>Tipo de servicio</label>
                                        <select class="form-control"  name="tipo" readonly> 
                                            <option><?php echo e($tipo->tipo); ?></option>                                                    
                                        </select>
                                    </div> 

                                    <div class="col-md-3 form-group">
                                        <label>Fecha salida</label>
                                        <input type="date" name="fecha_ingresa" class="form-control" value="<?php echo e($mantenimiento->fecha_ingresa); ?>" required 
                                        <?php if($mantenimiento->fecha_ingresa <= date("Y-m-d")): ?>
                                            readonly
                                        <?php else: ?>
                                        <?php endif; ?>
                                        >
                                    </div>
                                    
                                    <div class="col-md-3 form-group">
                                        <label>Fecha Regreso</label>
                                        <input type="date" name="fecha_salida" class="form-control" value ="<?php echo e($mantenimiento->fecha_salida); ?>" required>
                                    </div>

                                    <div class="col-md-3 form-group">
                                        <label>Kilometraje</label>
                                        <input type="number" step="0.00" name="kilometraje" id="" min="0.00" class="form-control" value="<?php echo e($mantenimiento->kilometraje); ?>"  required>
                                    </div>

                                    <div class="col-md-3 form-group">
                                        <label>Costo</label>
                                        <input type="number" step="0.01" name="costo" class="form-control" min="0.00" placeholder="0.00" value="<?php echo e($mantenimiento->costo_total); ?>" required>
                                    </div>
                                    <?php if($mantenimiento->status == "CURSO"): ?>
                                    <div class="col-md-6 form-group" style="margin-top: 3%;">
                                        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-warning" id="boton">Agregar Servicios</button>
                                        <button name = "finalizar" type="submit" class="btn btn-primary">Finalizar</button>
                                    </div> 
                                    <?php endif; ?>          
                                <!-- /.box-body -->
                            </form>
                    </div>
                    <div class="col-md-4">
                                    <div id="preview">
                                            <img src="<?php echo e('/images/'.$mantenimiento->foto); ?>"  style="width: 90%; height: 90%;" >  
                                    </div>                 
                    </div>

                </div>   



                <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-6 col-md-offset-4"><label>--Lista de servicios realizados al vehículo--<label></div>
                        </div>  
                    </div>
                    <div class="box-body">
                        <table id="example" class="display nowrap " style="width:100%">
                            <thead>
                                <tr>
                                    <th style="text-align: center">Número</th>
                                    <th >Servicios</th>
                                    <th >Descripción</th>
                                    <th >Fecha Alta</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0;?>
                                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <tr>
                                <td style="text-align: center"><?php 
                                echo $i=$i+1;
                                ?></td>
                                <td ><?php echo e($ser->nombreservicio); ?></td>
                                <?php if($ser->descripcion==null): ?>
                                <td style="text-align: center;" >----------------</td>
                                <?php else: ?>
                                <td ><?php echo e($ser->descripcion); ?></td>
                                <?php endif; ?>
                                <?php if($ser->fecha==null): ?>
                                <td style="text-align: center;">----------------</td>
                                <?php else: ?>
                                <td ><?php echo e($ser->fecha); ?></td>
                                <?php endif; ?>                        
                            </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>



              </div>
              <div class="modal " id="modal-warning">
                <div class="modal-dialog modal-lg" >
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;" title="Cerrar">
                        <span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
            
            <table class="table">
                
                    <?php $__currentLoopData = $taller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="col-md-4">     
                  <td class="col-md-1"><input type="checkbox" class="custom-control-input" id="<?php echo e($tal->nombreservicio); ?>" name="servicios[]" value="<?php echo e($tal->nombreservicio); ?>"></td>                  
                    <td class="col-md-11"><?php echo e($tal->nombreservicio); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              </table>
                          
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">Guardar</button>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
    </section>
   
    <div class="modal modal-warning fade" id="modal">
        <div class="modal-dialog" >
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Cancelar mantenimiento </b> </h4>
            </div>
            <div class="modal-body">
              <p>Está seguro cancelar&hellip;</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary pull-left" data-dismiss="modal">Cerrar</button>
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger">Continuar</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
        $(document).ready(function() {
             $('#example').DataTable( {
              "scrollY":"300px",
               "scrollX": true,
               "language": {
                 "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
               }
               
             } );
         } );
        </script>
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>

                  

</body>
</html>
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/gerente/mantenimiento/editar_mantenimiento.blade.php ENDPATH**/ ?>