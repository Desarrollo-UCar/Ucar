<!doctype html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <title>Ü-car Renta de vehículos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style type="text/css">
        .grid {
            display: grid;
            grid-template-areas: "head head"
                                "menu main"
                                "foot foot";
            }

            .a { grid-area: head; background: blue }
            .b { grid-area: menu; background: red }
            .c { grid-area: main; background: green }
            .d { grid-area: foot; background: orange }
      </style>
</head>
<body>
<section id="content">
<div >
<table class="table">
<tbody>
    <tr><td></td> <td><h2 style="color:dodgerblue"> Ü-Car </h2></td>      <td></td>                                           <td></td></tr>
    <tr><td></td>                                                 <td>---SALIDA DE VEHÍCULO---</td>                                           <td></td></tr>
    <tr><td></td>                                                 <td><?php echo e($sucursal->nombre); ?></td>                                    <td>Telefono:<?php echo e($sucursal->telefono); ?></td></tr>
    <tr><td></td>                                                 <td><p><?php echo e($sucursal->calle); ?>,<?php echo e($sucursal->numero); ?><br>    
                                                                         <?php echo e($sucursal->colonia); ?>,<br>
                                                                         <?php echo e($sucursal->municipio); ?>, <?php echo e($sucursal->estado); ?></p></td>   <td></td></tr>
</tbody>
</table>
<tr><td></td>    <td><p>Gracias por recoger su vehículo<br>para cualquier duda, favor de llamar al telefono <?php echo e($sucursal->telefono); ?>,<br> </p></td>   <td></td></tr>
<tr><td></td>  <td> Se le recuerda que debe de entregar el vehiculo en la misma sucursal en la fecha siguiente:</td>                                                                                                     </tr> 

<table class="table">
<tbody>    
    <?php $__currentLoopData = $reservacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td></td>  <td>Vehículo:</td>             <td><?php echo e($reserva->marca); ?> <?php echo e($reserva->modelo); ?> <?php echo e($reserva->anio); ?></td>  </tr>
    <tr><td>                </td>  <td>kilometraje:</td>          <td><?php echo e(number_format($reserva->kilometraje)); ?> km</td>  </tr>
    <tr><td>                </td>  <td>Fecha de Devolucion:</td>  <td><?php echo e($reserva->fecha_devolucion); ?></td>            <td>Hora de Devolución:</td>  <td> <?php echo e($reserva->hora_devolucion); ?> hrs</td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</section>
</body>
</html><?php /**PATH C:\laragon\www\Ucar\resources\views/mails/salida_de_vehiculo.blade.php ENDPATH**/ ?>