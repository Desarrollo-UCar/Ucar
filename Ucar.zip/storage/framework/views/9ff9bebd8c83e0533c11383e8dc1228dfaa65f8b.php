<?php $__env->startSection('seccion'); ?>
<section id="content">
    <div class="container">
        <div class="form-row"> 
            <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10">
                <h2>Hola <strong><?php echo e($cliente->nombre); ?> <?php echo e($cliente->primer_apellido); ?></strong> Consulta tu Historial de Reservas</h2>
            </div>
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                    <a href="<?php echo e(route('mi_perfil')); ?>" class="btn btn-primary"><i class="icon-chevron-down"></i>Mi Perfil</a>
            </div>
        </div>
<?php $__currentLoopData = $reservas_cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row border border-primary">
    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12"> <h3 class = "text-primary">Folio: <strong><?php echo e($reserva->id); ?></strong></h3></div>
    <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6">
        <div class="row">
        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
            <div id="lista_itinerario">
                <h6><strong>Tu Cotización:</strong></h6>    
                <table class="table table-sm">
                <tbody>
                    <tr><td><small>Kilometraje incluido</small></td>            <td><small>Ilimitado</small></td></tr>
                    <tr><td><small>Alquiler del automovil por 1 dia</small></td><td><small>$<?php echo e(number_format($reserva->precio,2)); ?></small></td></tr>
                    <tr><td><small><strong>Subtotal MXN <?php echo e($reserva->dias); ?> Dia(s)</strong></small></td> <td><small><strong>$<?php echo e(number_format($reserva->precio*$reserva->dias,2)); ?></strong></small></td></tr>
                    <?php $__currentLoopData = $cliente_serv_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($servicio->alquiler == $reserva->id_alquiler): ?>
                    <tr><td><small><?php echo e($servicio->nombre); ?></small></td>           <td><small>$<?php echo e($servicio->precio*$reserva->dias); ?>.00</small></td></tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><small><strong>Total</strong></small></td>          <td><small><strong>$<?php echo e(number_format($reserva->total,2)); ?></strong></small></td></tr>
                </tbody>
                </table>
            </div>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
            <div id="lista_itinerario">
                <h6><strong>Datos Generales:</strong></h6>    
                <dl>
                <dt>Lugar de Recogida y Devolución</dt>
                <dd><?php echo e($reserva->nombre); ?></dd>
                <dt>Fecha / Hora de recolección:</dt>
                <dd><?php echo e(date("d\-m\-Y", strtotime($reserva->fecha_recogida))); ?> a las <?php echo e($reserva->hora_recogida); ?> hrs</dd>
                <dt>Fecha / Hora de devolución:</dt>
                <dd><?php echo e(date("d\-m\-Y", strtotime($reserva->fecha_devolucion))); ?> a las <?php echo e($reserva->hora_devolucion); ?> hrs</dd>
                </dl> 
            </div>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
         <!--  boton para realizar cambio en la resreva 
         <a href="<?php echo e(route('modificar_reserva',['id'=>$reserva->id])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-cog"></i> Modificar</a>  -->
        </div>

        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
            <div class="container">
                <?php if($reserva->saldo != 0 ): ?>
                <div class="row">
                        <h6><strong>Saldo pendiente:  <i class="ico icon-circled active icon-1x fa-1x fa fa-usd text-success" ></i> <?php echo e(number_format($reserva->saldo,2)); ?> MXN</strong></h6>    
                </div>
                <?php else: ?>
                <div class="row">
                    <h5><strong>Pagado:</strong> <i class="ico icon-circled active icon-3x fa-3x fa fa-check text-success" ></i></h5>       
                    </div>
                    <?php endif; ?>
            </div>
        </div>
        </div>
    </div>
                <div class="col-sm-4 col-md-4 col-lg-2 col-xl-2">    
                    <div id="lista_itinerario">
                        <h6><strong>Tu vehículo:</strong></h6>  
                        <dl>
                        <dt><?php echo e($reserva->marca); ?> <?php echo e($reserva->modelo); ?></dt>
                        <?php if($reserva->tipo != "motoneta"): ?>
                        <dd><i class="fa fa-male"       aria-hidden="true"></i> <small> <?php echo e($reserva->pasajeros); ?> Pasajeros </small></dd>
                        <dd><i class="fa fa-suitcase"   aria-hidden="true"></i><small> <?php echo e($reserva->maletero); ?></small></dd>
                        <dd><i class="fa fa-car"   aria-hidden="true"></i> <small><?php echo e($reserva->puertas); ?> Puertas</small></dd>
                        <dd><i class="fa fa-exchange"aria-hidden="true"></i> <small>Transmisión <?php echo e($reserva->transmicion); ?></small></dd>
                        <dd><i class="fa fa-snowflake-o"aria-hidden="true"></i> <small><?php echo e($reserva->cilindros); ?> Cilindros</small></dd>
                        <dd><i class="fa fa-bolt"       aria-hidden="true"></i> <small><?php echo e($reserva->rendimiento); ?> Kilómetros por litro</small></dd>
                        <dd><i class="fa fa-bolt"       aria-hidden="true"></i> <small>Color: <?php echo e($reserva->color); ?></small></dd>
                        <?php else: ?>
                        <dd><i class="fa fa-snowflake-o"aria-hidden="true"></i> <small><?php echo e($reserva->cilindros); ?> Cilindros</small></dd>
                        <dd><i class="fa fa-bolt"       aria-hidden="true"></i> <small><?php echo e($reserva->rendimiento); ?> Kilómetros por litro</small></dd>
                        <dd><i class="fa fa-bolt"       aria-hidden="true"></i> <small>Color: <?php echo e($reserva->color); ?></small></dd>
                        <?php endif; ?>
                        </dl>   
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="container">
                        <div class="row">
                                <img src="<?php echo e('/images/'.$reserva->foto); ?>" style="width:100%" />
                                <h6><i class="ico icon-circled active icon-1x fa-1x fa fa-window-close text-danger" ></i><strong> Cancelar:</strong> Favor de ponerse en contacto con la sucursal al número: <?php echo e($reserva->telefono); ?></h6>       
                        </div>
                    </div>
                </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/dashboard_cliente.blade.php ENDPATH**/ ?>