<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Verifica Tu Direccion De Correo Electrónico')); ?></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Se ha enviado un nuevo enlace de verificación a su dirección de correo electrónico.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Antes de continuar, revise su correo electrónico para obtener un enlace de verificación')); ?>

                    <?php echo e(__('Si no recibiste el correo electrónico')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('Haga clic aquí para solicitar otro')); ?></a>.
                    <input type='button' class="btn btn-primary" value='Continuar' onClick='history.go(-2);'>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/auth/verify.blade.php ENDPATH**/ ?>