<?php $__env->startSection('styles'); ?>
  <!-- Morris chart -->
  <link rel="stylesheet" href="<?php echo e(asset("assets/$theme/bower_components/morris.js/morris.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<section class="content-header">
    <h1>
      Panel de administracion
      <small>Gerente</small>
    </h1>
</section>
<section class="content">


          <div class="row"> 
              <div class="col-md-12 ">
                <!-- Line chart -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <i class="fa fa-bar-chart-o"></i>
      
                  <h3 class="box-title"><?php echo e($titulo); ?> </h3>
    
                  </div>
                  <div class="box-body">
                      <div class="col-md-2"></div>
                      <div class="col-md-7">
                    <div id="bar-chart2-mantenimientos" style="height: 350px;"></div>
                    </div>
                  </div>
                  <!-- /.box-body-->
                </div>
              </div>


      </div>


  
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<!-- Morris.js charts -->
<script src="<?php echo e(asset("assets/$theme/bower_components/raphael/raphael.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/$theme/bower_components/morris.js/morris.min.js")); ?>"></script>

<!-- jvectormap -->
<script src="<?php echo e(asset("assets/$theme/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/$theme/plugins/jvectormap/jquery-jvectormap-world-mill-en.js")); ?>"></script>

<!-- jQuery Knob Chart-->
<script src="<?php echo e(asset("assets/$theme/bower_components/jquery-knob/dist/jquery.knob.min.js")); ?>"></script>

<!-- FLOT CHARTS -->
<script src="<?php echo e(asset("assets/$theme/bower_components/Flot/jquery.flot.js")); ?>"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="<?php echo e(asset("assets/$theme/bower_components/Flot/jquery.flot.resize.js")); ?>"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="<?php echo e(asset("assets/$theme/bower_components/Flot/jquery.flot.pie.js")); ?>"></script>
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="<?php echo e(asset("assets/$theme/bower_components/Flot/jquery.flot.categories.js")); ?>"></script>
<script>
    $(function () {
                //BAR CHART mantenimientos general
    var bar = new Morris.Bar({
      element: 'bar-chart2-mantenimientos',
      resize: true,
      data: <?php echo json_encode($datos, 15, 512) ?>,
      barColors: ['#4AB0FC'],
      xkey: <?php echo json_encode($x, 15, 512) ?>,
      ykeys: [<?php echo json_encode($y, 15, 512) ?>],
      labels: [<?php echo json_encode($etiqueta, 15, 512) ?>],
      hideHover: 'auto',
      fillOpacity: 100
    });
    //FIN BARCHART AÑO

      /*
       * END DONUT CHART
       */
  
    })
  
    /*
     * Custom Label formatter
     * ----------------------
     */
    function labelFormatter(label, series) {
      return '<div style="font-size:13px; text-align:center; padding:2px; color: #fff; font-weight: 600;">'
        + label
        + '<br>'
        + Math.round(series.percent) + '%</div>'
    }
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme.$theme.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ucar\resources\views/gerente/reportes/mantenimientos.blade.php ENDPATH**/ ?>